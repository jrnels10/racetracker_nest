// export interface Event {
//   id: string;
//   title: string;
//   description: string;
//   location: string;
//   duration: number;
//   length: number;
//   registration: EventRegistration;
//   date: Date;
//   status: EventStatus;
// }

// export enum EventRegistration {
//   OPEN = 'OPEN',
//   CLOSED = 'CLOSED',
// }
// export enum EventStatus {
//   ACTIVE = 'ACTIVE',
//   CANCELLED = 'CANCELLED',
//   DONE = 'DONE',
//   TBD = 'TBD',
//   POSTPONED = 'POSTPONED',
// }
